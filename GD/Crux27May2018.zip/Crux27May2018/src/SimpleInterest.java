
/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class SimpleInterest {

	public static void main(String[] args) {

		int p = 100;
		int r = 10;
		int t = 20;

		int si = (p * r * t) / 100;

		System.out.println("Simple Interest is : " + si + " .");
	}

}
