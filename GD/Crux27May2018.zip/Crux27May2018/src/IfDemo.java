
/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class IfDemo {

	public static void main(String[] args) {

		int marks = 70;
		int pack = 30;

		if (marks >= 80 && pack >= 20) {
			System.out.println("good");
		} else {
			System.out.println("avg");
		}

	}

}
