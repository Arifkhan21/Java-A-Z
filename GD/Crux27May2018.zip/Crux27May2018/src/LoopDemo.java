
/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class LoopDemo {

	public static void main(String[] args) {

		// initialization
		int counter = 1;

		// condition
		while (counter <= 10) {
			System.out.println(counter);
			
			// reinitialization
			counter = counter + 1;
		}

		System.out.println(counter);
		System.out.println("bye");
	}

}
