
/**
 * @author Garima Chhikara
 * @email garima.chhikara@codingblocks.com
 */

public class Pattern0 {

	public static void main(String[] args) {

		int n = 5;

		// no of rows
		int row = 1;

		while (row <= n) {

			// work
			System.out.print("*");

			// prep
			System.out.println();
			row = row + 1;
		}

	}

}
